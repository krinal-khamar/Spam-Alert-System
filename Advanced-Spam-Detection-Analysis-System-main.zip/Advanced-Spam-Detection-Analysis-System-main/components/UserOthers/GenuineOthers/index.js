import React from 'react'
import { View, Text, Button, FlatList, ActivityIndicator, StyleSheet } from 'react-native';

function GenuineOthers() {
  return (
   <View>
    <Text>GenuineOthers</Text>
   </View>
  )
}

export default GenuineOthers