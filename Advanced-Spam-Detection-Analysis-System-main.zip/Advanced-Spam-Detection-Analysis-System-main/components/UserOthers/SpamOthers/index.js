import React from 'react'
import { View, Text, Button, FlatList, ActivityIndicator, StyleSheet } from 'react-native';

function SpamCalls() {
  return (
   <View>
    <Text>SpamCalls</Text>
   </View>
  )
}

export default SpamCalls