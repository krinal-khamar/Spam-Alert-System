// import React from 'react';
// import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';
// import {createNativeStackNavigator} from '@react-navigation/native-stack';
// import { NavigationContainer } from '@react-navigation/native';
// import SpamSMS from '../SpamSMS/index';
// import GenuineSMS from '../GenuineSMS/index';

// const Tab = createMaterialTopTabNavigator();
// const Stack = createNativeStackNavigator();

// function NewScreennn() {
//   return (
//     <Tab.Navigator>
//       <Tab.Screen name="SpamSMS" component={SpamSMS} options={{ headerShown: false, title: 'Rakshak2' }} />
//       <Tab.Screen name="GenuineSMS" component={GenuineSMS} options={{ headerShown: false, title: 'Rakshak3' }} />
//     </Tab.Navigator>
//   );
// }

// export default NewScreennn;
