export const Apilayerapikey = "eQo283Y3g4gt52Gqa321CjcoK7AsFFnL"
